# Smart Campus Management System
