# AI Face Recognition Module for Smart Campus
